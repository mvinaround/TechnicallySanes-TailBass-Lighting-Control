Extract all files to a folder and run 'Tailbass Lighting Control.exe'

Any problems DM TechnicallySane#8427 on discord :)